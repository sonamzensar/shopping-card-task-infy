# README #

Shopping Cart 

### FEATURES ###

* Product List
* Add to cart functionality
* Add/Remove/Increase/Decrease Quantity

### How do I get set up? ###


* npm i
* npm run build [for prod]
* npm run build:dev [for dev]
* npm start
* npm test [for tests]

