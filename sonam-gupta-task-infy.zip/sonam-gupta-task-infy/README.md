# README #

Shopping Cart 

### FEATURES ###

* Product List
* Add to cart functionality
* Add/Remove/Increase/Decrease Quantity

### How do I get set up? ###


* npm i
* npm start
* npm test [for tests]

