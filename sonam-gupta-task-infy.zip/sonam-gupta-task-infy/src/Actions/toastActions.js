const showHideToastAction = payload => ({
  type: 'TOAST',
  payload,
});
export default showHideToastAction;
